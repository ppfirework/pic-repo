package cn.pprocket.pt.item;

import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.registries.IForgeRegistry;

@Mod.EventBusSubscriber
public class ItemRegister {
    public static Board board = new Board();
    @SubscribeEvent
    public static void  reg(RegistryEvent.Register<Item> e){
        IForgeRegistry<Item> registry = e.getRegistry();
        registry.register(board);
    }
}
