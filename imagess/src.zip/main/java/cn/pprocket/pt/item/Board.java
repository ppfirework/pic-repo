package cn.pprocket.pt.item;

import cn.pprocket.pt.Pt;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class Board extends Item {
    public Board(){
        this.setTranslationKey(Pt.MOD_ID+"board");
        this.setRegistryName("board");
        this.setMaxStackSize(16);
        this.setCreativeTab(CREATIVE_TAB);
    }
    public static final CreativeTabs CREATIVE_TAB = new CreativeTabs("物品栏") {
        @Override
        public ItemStack createIcon() {
            return new ItemStack(Items.DIAMOND);
        }
    };

}

